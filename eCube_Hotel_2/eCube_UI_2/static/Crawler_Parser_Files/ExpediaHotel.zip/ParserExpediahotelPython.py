visitHomePage = False
requestType = {
    'request': True,
    'driver': False,
}
