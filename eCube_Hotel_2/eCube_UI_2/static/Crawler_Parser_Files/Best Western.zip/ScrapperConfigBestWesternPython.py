visitHomePage = False
requestType = {
    'request': True,
    'driver': False,
}

hotelcodepattern='hotelCode\W+([\w].*?)",'
apikeypattern='apiKey\W+"([\w]*)\W+,'
apitokenpattern='apiToken\W+"([\w\s].*?)\W+,'


rcpattern='"roomCode":"([\w].*?)"'